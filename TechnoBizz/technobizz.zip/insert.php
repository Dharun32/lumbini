<!DOCTYPE html>
<html>


<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script type="text/javascript">

$(document).ready(function(){

    $("#more").mouseenter(function(){

        $("#more").css("background-color","#3898ff");

    });

      $("#more").mouseleave(function(){

        $("#more").css("background-color","#eba023");

    });

});

$(document).ready(function(){

    $("#model").mouseenter(function(){

        $("#model").css("background-color","#3898ff");

    });

      $("#model").mouseleave(function(){

        $("#model").css("background-color","#eba023");

    });

});


$(document).ready(function(){


    $("#design").mouseenter(function(){

        $("#design").css("background-color","#3898ff");

    });


      $("#design").mouseleave(function(){

        $("#design").css("background-color","#eba023");

    });

});


$(document).ready(function(){


    $("#lenovo").mouseenter(function(){

        $("#lenovo").css("background-color","#3898ff");


    });

      $("#lenovo").mouseleave(function(){

        $("#lenovo").css("background-color","#eba023");

    });


});

$(document).ready(function(){

    $("#mobile").mouseenter(function(){

        $("#mobile").css("background-image","url(img/sign111.png)");


    });

      $("#mobile").mouseleave(function(){

        $("#mobile").css("background-image","url(img/border.png)");

    });

});

$(document).ready(function(){

    $("#bulb").mouseenter(function(){

        $("#bulb").css("background-image","url(img/sign111.png)");

    });


      $("#bulb").mouseleave(function(){

        $("#bulb").css("background-image","url(img/border.png)");

    });

});

$(document).ready(function(){

    $("#globe").mouseenter(function(){

        $("#globe").css("background-image","url(img/sign111.png)");

    });

      $("#globe").mouseleave(function(){

        $("#globe").css("background-image","url(img/border.png)");

    });

});

$(document).ready(function(){


    $("#chess").mouseenter(function(){

        $("#chess").css("background-image","url(img/sign111.png)");

    });

      $("#chess").mouseleave(function(){

        $("#chess").css("background-image","url(img/border.png)");

    });

});


</script>

<style type="text/css">
    
@media(max-width: 800px){
.sf-menu{display: none;}
}
</style>

<style type="text/css">

#mono{

    width:80px;
    height:30px;
   /* margin-left:-174px;*/

}

#test{

     border: 1px solid #88c1ff;
    background-color: #88c1ff;
    border-radius: 23px;
    width: 100%;

}

#more{

 width: 50px;
 height: 50px;
 background-color: #eba023;
 border-radius: 50px;
 position: absolute;
 padding-top: 15px;
 padding-left:2px;

}

#model{
 width: 50px;
 height: 50px;
 background-color: #eba023;
 border-radius: 50px;
 position: absolute;
 padding-left: 2px;
 padding-top: 15px;

}

#design{
 width: 50px;
 height: 50px;
 background-color:#eba023;
 border-radius: 50px;
 position: absolute;
 padding-left: 2px;
padding-top: 15px;
}



#lenovo{

 width: 50px;
 height: 50px;
 background-color:#eba023;
 border-radius: 50px;
 position: absolute;
 padding-left: 2px;
 padding-top: 15px;
}

.swat:hover{
    background-color:#f5f5f5;

}
    #mobile{

        width:200px;
        height:200px;
        background-image: url("img/border.png");
        background-repeat: no-repeat;
        margin-left:39px;
    }

    .topcenter{

    width: 90px;
    height: 77px;
    margin-top: 60px;
    margin-left: 28px;

    }

    #bulb{

        width:200px;
        height:200px;
        background-image: url("img/border.png");
        background-repeat: no-repeat;
        margin-left:34px;

    }

    .bulbcenter{

    width: 80px;
    height: 77px;
    margin-left: 65px;
    margin-top: 58px;

    }

    #globe{

        width:200px;
        height:200px;
        background-image: url("img/border.png");
        background-repeat: no-repeat;
        margin-left:31px;

    }
.gm-style .place-card-large {
    padding: 9px 4px 9px 11px;
    display: none !important;
}
    .globecenter{
    width: 80px;
    height: 77px;
    margin-left: 65px;
    margin-top: 58px;

    }

    #chess{

        width:200px;
        height:200px;
        background-image: url("img/border.png");
        background-repeat: no-repeat;
        margin-left:39px;

    }

    .chesscenter{

    width: 46px;
    height: 77px;
    margin-left: 75px;
    margin-top: 58px;

   }


    </style>
    </head>

<body>
<div><?php include("include/header.php"); ?></div>

<section class="tp-banner-container"  style="width:100%;">
        <div class="tp-banner" >
            <ul>
                <!-- SLIDE 3-->
                <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" data-x="center" data-y="center">
                    <!-- MAIN IMAGE -->
                    <img src="sliderimages/analytic.jpg" alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                    <!-- LAYERS -->
                   <!-- LAYER NR. 1 -->
                   <div class="tp-caption  skewfromleft customout"
                        data-x="117"
                        data-y="321"
                        data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                        data-speed="600"
                        data-start="1800"
                        data-easing="Power4.easeOut"
                        data-endspeed="600"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="on"
                        style="z-index: 6"><a href="SAP-analytics.php" class="button_big4" style="margin-top:-140px;margin-left:-45px;color:black;"><h3>SAP ANALYTICS (BI, BO )</h3><h4>Business Inteligence<br>
                            BusinessObjects Dasboards<br>
                            BusinessObjects Webi Reports<br>
                            KPIs & Scorecards<br>
                            BusinessObjects DataServices & Integrations<br>
                            HANA</h4>
                            <img src="img/read.png" style="width:150px; height=150px;" ></a>
                    </div>
                </li>
                   <!--slide4-->
                <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" data-x="center" data-y="center">
                    <!-- MAIN IMAGE -->
                    <img src="sliderimages/banner5.jpg" alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                    <!-- LAYERS -->
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption  skewfromleft customout"
                        data-x="117"
                        data-y="321"
                        data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                        data-speed="600"
                        data-start="1200"
                        data-easing="Power4.easeOut"
                        data-endspeed="600"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="on"
                        style="z-index: 6"><a href="http://bpc.lumbinielite.com/" class="button_big4" style="margin-top:-125px;margin-left:-55px;color:black;"><h3>BUSINESS PLANNING & CONSOLIDATION</h3>
                        <h4>Lumbini offers SAP Business Planning & Consolidation<br/>
                        solution helps automate and streamline your planning, 
                        <br/>budgeting, forecasting, and consolidation activities for <br/>
                        shorter budget cycles, a faster closer, and improved<br/> 
                        regulatory compliance.</h4>
                        <img src="img/read.png" style="width:150px; height=150px;" >
                        </a>
                    </div>
                </li>
                   <!--Slide2-->
                <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" data-x="center" data-y="center">
                    <!-- MAIN IMAGE -->
                    <img src="sliderimages/crm1.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                    <!-- LAYERS -->
                   <!-- LAYER NR. 1 -->
                    <div class="tp-caption  skewfromleft customout"
                        data-x="117"
                        data-y="321"
                        data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                        data-speed="600"
                        data-start="1200"
                        data-easing="Power4.easeOut"
                        data-endspeed="600"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="on"
                        style="z-index: 6">
                        <a href="SAP-analytics.php"  class="button_big4" style="margin-top:-135px;margin-left:-55px;color:black;"><h3>SAP HANA</h3>
                        <h4>Acquire and store petabytes of data from any source.<br/>
                        Run processes 1,000 to 100,000 times faster in-memory<br/> 
                        with SAP HANA. Analyse billions of rows within seconds.<br/>
                        Our SAP HANA Services include HANA Modelling<br>HANA Administration</h4> 
                            <img src="img/read.png" style="width:150px; height=150px;" >
                        </a>
                    </div>
                </li>
                <!-- SLIDE 1-->
                <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" data-x="center" data-y="center">
                    <!-- MAIN IMAGE -->
                   <img src="sliderimages/mobility.jpg" alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                    <!-- LAYERS -->
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption  skewfromleft customout"
                        data-x="117"
                        data-y="321"
                        data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                        data-speed="600"
                        data-start="1200"
                        data-easing="Power4.easeOut"
                        data-endspeed="600"
                        data-endeasing="Power1.easeIn"
                        data-captionhidden="on"
                        style="z-index: 6">
                        <a href="SAP-mobility.php"  class="button_big4" style="margin-top:-115px;margin-left:-55px;color:black;"><h3>MOBILITY</h3><h4>Use of mobile technology has become an inevitable <br/>
                        part of every business.Our Expertises lies in Android<br/>
                         & IOS Development, SUP, Afaria, Cyclo & Syclo</h4>
                           <img src="img/read.png" style="width:150px; height=150px;">
                        </a>
                   </div>
                </li>
            </ul>
        </div>
</section><!-- End slider --><!-- End slider -->
<section id="main-featured">

    <div class="container">

        <div class="row">
          <div class=" col-md-12 col-md-offset-1 text-center">

                <h2><img src="img/left line.png">&nbsp OUR OFFERINGS ON SAP  TECHNOLOGIES</h2>

                <p class="lead">
                    Lumbini Elite is a vibrant company with focus on SAP Technologies<b>.</b>&nbsp Presently we are offering services in varied areas of SAP.<br><br>Some of our focus area are as below.
                </p>

            </div>

        </div>


        <div class="row">


            <div class="col-md-3">

                <div class="feature" >

                    <h3>Analytics</h3>

               <li style= "color:#fbb700;"> <a  href="SAP-analytics.php" style="color:#939598;">  Business Intelligence </a></li>

                 <li style= "color:#fbb700;"> <a   href="SAP-analytics.php" style="color:#939598;">  Enterprise Performance Management </a></li>

                    <li style= "color:#fbb700;"> <a   href="SAP-analytics.php" style="color:#939598;"> Governance, Risk and Compliance </a></li>

  <li style= "color:#fbb700;"> <a   href="SAP-analytics.php" style="color:#939598;">Predictive Analytics </a></li>

 <li style= "color:#fbb700;"> <a   href="SAP-analytics.php" style="color:#939598;"> BO & HANA </a></li>

</br>

                </div>

            </div>

            <div class="col-md-3">

                <div class="feature">
                
                  <h3>Netweaver</h3>

                    <li style= "color:#fbb700;"> <a  href="SAP-NETWEAVER.php" style="color:#939598; width:119%"> Security </a></li>

                 <li style= "color:#fbb700; width:241px;"> <a href="SAP-NETWEAVER.php" style="color:#939598; width:133%"> Data Integration and Data Quality </a></li>

                <li style= "color:#fbb700;"> <a href="SAP-NETWEAVER.php" style="color:#939598; width:119%"> ABAP Technology </a></li>

  <li style= "color:#fbb700;"> <a href="SAP-NETWEAVER.php" style="color:#939598; width:119%">Workflow </a></li>

 <li style= "color:#fbb700;"> <a href="SAP-NETWEAVER.php" style="color:#939598; width:119%"> Integration </a></li>

</br>

                </div>

            </div>

            <div class="col-md-3">

                <div class="feature">

                    <h3>Mobile Technology</h3>

                        <li style= "color:#fbb700;"> <a href="SAP-mobility.php" style="color:#939598;"> Enterprise Mobility Management </a></li>

                 <li style= "color:#fbb700;"> <a href="SAP-mobility.php"  style="color:#939598;"> SUP/SMP </a></li>

                    <li style= "color:#fbb700;"> <a href="SAP-mobility.php"  style="color:#939598;"> Mobile Application Development Platform </a></li>

  <li style= "color:#fbb700;"> <a href="SAP-mobility.php"  style="color:#939598;">Mobile Apps  </a></li>

                </div>

            </div>

            <div class="col-md-3">

                <div class="feature">

                 <h3>Cloud Technology</h3>

                 <li style= "color:#fbb700;"> <a  href="hana.php" style="color:#939598; width:119%">  HANA Platform </a></li>

                 <li style= "color:#fbb700; width:241px;"> <a  href="aws.php" style="color:#939598; width:133%"> AWS</a></li>

                 <li style= "color:#fbb700; width:241px;"> <a  href="azure.php" style="color:#939598; width:133%"> AZURE</a></li>

               </div>

            </div>

        </div><!-- End row -->

        </div><!-- End container-->

    </section><!-- End main-features -->

 <section id="main-features">

    <div class="container">

        <div class="row">

            <div class=" col-md-12 text-center">

                <h2 style="color:#5f5f5f; margin-top:-76px; margin-left:25px;"> <img src="img/left line.png" style="width:80px; height:30px;"><strong> OUR SERVICES</strong></h2>

                          </div>
            </div>

        </div>
   
        <div class="col-md-12">

            <div class="col-md-3 swat">

            <div class="feather">

            <div id="chess">

            <a href="services-consulting.php">

                <img src="img/chess.png" class="chesscenter"> </div>

                   <h3 style="color:#353943;font-size:18px;"><center>STRATEGY & CONSULTING</center></h3>

                    <p style="text-align:justify; ">

                         Lumbini Elite provides system Readiness and do audit as an independent agency. The Systems performance, Archiving, BackUp, etc are part of these services.

 <CENTER><p  id="more" style="margin-left:-39px;margin-top:40px;position:relative;color:white">More</p></CENTER>

                   </p>

                  </a>

                </div>

            </div>

            <div class="col-md-3 swat">

                <div class="feather">

                <div id="globe">

                <a href="supportnmaintainence.php">

                   <img src="img/globe.png" class="globecenter"> </div>

                    <h3 style="color:#353943;font-size:18px; text-align:center;">SUPPORT AND MAINTENANCE</h3>

                    <p  style="text-align:justify;"> 

                    Our flexible engagement models have been well received by our Customers, who have not only found great value and quality but all the flexibility they could ever imagine.

 <CENTER><p  id="model" style="margin-left:-39px;margin-top:40px; position:relative;color:white">More</p></CENTER>

                    </p>

                  </a>

                  </div>

            </div>

            <div class="col-md-3 swat">

                <div class="feather">

                 <div id="bulb">

                 <a href="design and development.php">

                    <img src="img/Layer 29.png"  class="bulbcenter">    </div>

                    <h3 style="color:#353943;font-size:18px;"><center>DESIGN & DEVELOPMENT</center></h3>

                    <p style="text-align:justify;">

                        We take a pragmatic approach to solution design, recognising that customers tend to be overwhelmed with complex technological changes.

 <CENTER><p  id="design" style="margin-left:-20px;margin-top:59px; position:relative;color:white">More</p></CENTER>

                   </p>

                   </a>

                 </div>

            </div>

              <div class="col-md-3 swat">

               <div class="feather">

                 <div id="mobile">

                 <a href="mobile.php">

                 <center>

                   <img src="img/msign.png"  class="topcenter"></center></div>

                    <h3 style="color:#353943;font-size:18px;"><center>MOBILE DEVELOPMENT</center></h3>
                    <p style="text-align:justify;">
                        We provide best in class, most cost-effective service in mobile app development. We are expert in  Public Sector, Retail and Telecom mobile Apps.
                         <CENTER><p  id="lenovo" style="margin-left:-20px; margin-top:59px; position:relative;color:white">More</p></CENTER>
  </p>

  </a>
                      </div>
            </div>

        </div><!-- End row -->

        </div><!-- End container-->

    </section><!-- End main-features -->
<div class="clearfix"></div>
<div class="clearfix"></div>

    <section id="testimonials">

        <div class="container">

            <div class="row">

                <div class='col-md-offset-2 col-md-8 text-center'>

                    <h2> <img src="img/left line_1.png" id="mono">&nbsp&nbspTESTIMONIALS </h2>

                </div>


            </div>
            <center>
                <div class='row' id="test">
                <div class='col-md-offset-2 col-md-8'>
                    <div class="carousel slide" data-ride="carousel" id="quote-carousel">

                        <ol class="carousel-indicators">
                            <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>

                            <li data-target="#quote-carousel" data-slide-to="1"></li>

                            <li data-target="#quote-carousel" data-slide-to="2"></li>

                             <li data-target="#quote-carousel" data-slide-to="3"></li>

                              <li data-target="#quote-carousel" data-slide-to="5"></li>
                        </ol>

                        <div class="carousel-inner">
                            <div class="item active">

                                <blockquote>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <p>

                                               The project was a success and Lumbini Elite hit all the milestones with panache.
                                            </p >

                                        </div>

                                    </div>
                                </blockquote>
                            </div>

                            <div class="item">

                                <blockquote>

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <p>
                                    For me Lumbini Elite is the forerunner in the area of system, security and controls.
                                            </p>
                                        </div>
                                    </div>

                                </blockquote>

                            </div>

                            <div class="item">


                                <blockquote>
                                    <div class="row">

                                        <div class="col-sm-12">
                                            <p>
                                              I'll definitely be using them in the future and they are the first to call for anything in security or authorisation.

                                            </p>

                                        </div>
                                    </div>
                                </blockquote>

                            </div>

                             <div class="item">

                                <blockquote>
                                    <div class="row">

                                        <div class="col-sm-12">
                                            <p>
                                                Lumbini Elite Solutions is a real expert in SAP BPC. With little guidance, they over delivered on the brief.

                                            </p>                                  
                                        </div>
                                    </div>
                                </blockquote>
                            </div>
                             <div class="item">
                                <blockquote>
                                    <div class="row">

                                        <div class="col-sm-12">

                                            <p>
                                              They not only delivered the policies required, but also delivered really useful step by step implementation guides.

                                            </p>                                       

                                        </div>
                                    </div>
                                </blockquote>
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
            </center>

            
        </div>

       </section><!-- End testimonials -->
       <div class="clearfix"></div>

 <section>

 <div class="row">

 <div class="col-md-6" style="background-color:#f0d47f;">

        <center><p style="margin-top:20px;font-size:34px; color:white;">
        <img src="img/left line_1.png" style="width:80px; height:30px;"> &nbsp&nbsp&nbspCONTACT US </p></center>

        <form name="phpformmailer" action="mail_process.php" align="center" method="post">
	        <div class="row">
	        	<div class="col-md-6 col-xs-6"> <input  name="name" placeholder=" Name" style="border-radius:5px;margin-top: 20px;padding-left: 13px; width:243px;height:40px; border:none;"></div>
	        	<div class="col-md-6 col-xs-6"><input type="email"  name="email" placeholder=" EMAIL" style="border-radius:5px;margin-top: 20px;padding-left: 13px; width:243px;height:40px; border:none;"></div>

	        </div><br/>
			  <input type="text"  name="phonenumber" placeholder="Contact Number" style="padding-left: 20px; width:90%; margin-bottom: 25px; border-radius:5px;height: 40px; border:none;"><br/> 
			  <textarea style="font-size:14px; width: 90%;height:172px;; border-radius:10px; border:none;padding-left: 20px;padding-top:12px;"   name="themessage" placeholder="MESSAGE"></textarea> 

				<br>                
				<center>
				 <input type="submit" class="button" value="Submit" name="contact" onclick="myFunction()" style="border:1px #3880f3; background-color:#3880f3; width:157px;color:#ffffff; height:40px;border-radius:5px; border:none;    margin-bottom: 5%;">	
				</center>
    
       </form>

 </div>

 <div class="col-md-6">

<iframe width="107%" height="465" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15550.623903132951!2d77.71770516931142!3d12.993841966080447!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1195c1a788fb%3A0xd2d3ca2b10c2e924!2sMeghana+Nursing+Home!5e0!3m2!1sen!2sin!4v1404636601354"></iframe><br />

  </div>

  </div>

  </section><!-- end map-->

 <div><?php include("include/footer.php"); ?></div>

<div id="toTop">Back to top</div>
<script src="js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

<script type="text/javascript">

       var revapi;

       jQuery(document).ready(function() {
		 revapi = jQuery('.tp-banner').revolution(

                {
                    delay:6000,
                    startwidth:1170,
                    startheight:500,
                    hideThumbs:true,
                    navigationType:"none",
                    fullWidth:"on",
                    forceFullWidth:"on"
                });

        }); 

    </script>

<script src="js/superfish.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/retina.min.js"></script>
<script src="assets/validate.js"></script>
<script src="js/jquery.placeholder.js"></script>
<script src="js/functions.js"></script>
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script>new UISearch( document.getElementById( 'sb-search' ) );</script>
<script>
$(document).ready(function(){
    $(".tp-banner-container").css("display", "block");
        
});
</script>
<script>
function myFunction() {
    alert("Thanks you for Query!");
}
</script>

  </body>

</html>