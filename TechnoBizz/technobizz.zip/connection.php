<?php


function Connect()
{
 $dbhost = "technobizz.db.11980050.552.hostedresource.net";
 $dbuser = "technobizz";
 $dbpass = "Password@12345";
 $dbname = "technobizz";

 // Create connection
 $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname) or die($conn->connect_error);

 return $conn;
}
 
?>