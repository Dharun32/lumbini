<!DOCTYPE HTML>
<html>
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Technobizz</title><link rel="icon" href="photos/single_logo.png" type="image/png">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="author" content="Sabina bano" />
		<link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Themify Icons-->
		<link rel="stylesheet" href="css/themify-icons.css">
		<!-- Bootstrap  -->
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Owl Carousel  -->
		<link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Theme style  -->
		<link rel="stylesheet" href="css/style.css">
		<!-- Modernizr JS -->
		<link rel="stylesheet" type="text/css" href="dist/zoomslider.css" />
		<script type="text/javascript" src="js/modernizr-2.6.2.min.js"></script>
		<!-- FOR IE9 below -->
		<!--[if lt IE 9]>
		<script src="js/respond.min.js"></script>
		<![endif]-->


<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5a54b15cd7591465c7069224/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


</head>
<body>
		
	<div class="gtco-loader"></div>
	<div id="page">
		<nav class="gtco-nav" role="navigation">
				<div class="gtco-container">
					<div class="row">
						<div class="col-sm-2 col-xs-12">
							<div id="gtco-logo"><a href="index.php"><img src="photos/logo.png" style="width: 234px;"></a></div>
						</div>
						<div class="col-xs-10 text-right menu-1 main-nav">
							<ul>
								<li class="active"><a href="#" data-nav-section="home">Home</a></li>
								<li><a href="#" data-nav-section="features">About Us</a></li>
								<li><a href="#" data-nav-section="Services">Services</a></li>
								<li><a href="#" data-nav-section="customers">Customers</a></li>	
								<li><a href="#" data-nav-section="products">Products</a></li>
								<li><a href="#" data-nav-section="blogs">Blogs</a></li>			
								<li><a href="#" data-nav-section="contact">Contact Us</a></li>
							</ul>
							
						</div>
					</div>
				</div>
		</nav>

		<div id="demo-1" data-section="home" data-zs-src='["photos/desk-slide.jpg", "photos/lightbulb-slide.jpg", "photos/Digital-marketing.jpg","photos/Digital.jpg"]' data-zs-overlay="dots">
			<div class="demo-inner-content">
					<p class="item-1"><span>We are a brand marketing firm </span><br><span>dedicated to our clients</span></p>
					<p class="item-2">We are a solution based marketing company</p>
					<p class="item-3">We add value to your business</p>
			</div>
		</div>
		<div id="gtco-features" class="border-bottom" data-section="features">
			<div class="gtco-container">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12 gtco-heading animate-box a1" data-animate-effect="fadeInRight">
							<h2 class="gtco-left">About Us</h2>
							<p class="textjustfy">We bring together  backed research and predictive campaign analysis along with an in-house team of experienced digital marketing professionals, to keep your brand ahead of the competition.</p>
							<p class="textjustfy">We create impactful content that engages digital amplification and omnichannels PR expertise to ensure the reach of the content to your relevant target group. Thus, increasing brand awareness and loyalty, generating leads and further establishing your brand as a Thought Leader.</p>
							<p class="textjustfy">TechnoBizz, also being an integral part of the ongoing process, succeeds in building and developing a brand that will stand up and last no matter the shifts in the economy or other issues the client may face.</p>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 animate-box" data-animate-effect="fadeInLeft">
						<img src="images/123.jpg" alt="img01" class="img-responsive imgborder">
					</div>
					<div class="clearfix"></div>
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<span><img src="photos/2.png" width="200px" height="200px"></span>
								<h3>Reliable</h3>
							</div>
						</div>
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<span><img src="photos/3.png" width="200px" height="200px"></span>
								<h3>Responsive</h3>
							</div>
						</div>
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<span><img src="photos/1.png" width="200px" height="200px"></span>
								<h3>Digital Reinvention</h3>
							</div>
						</div>
					</div>					
				</div>
			</div>
		</div>

		<div class="gtco-section border-bottom" id="how-it-works" data-section="Services">
			<div class="gtco-container">
					<div class="row">
						<div class="col-md-12 gtco-heading" style="margin-left: 34px;">
							<h2 class="gtco-left">Services</h2>
							
						</div>
					</div>
					<!-- 			<div class="row">
							<div class="owl-carousel owl-carousel-carousel">
									<div class="item">
											<img src="images/img_1.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
									<div class="item">
											<img src="images/img_2.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
									<div class="item">
											<img src="images/img_3.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
									<div class="item">
											<img src="images/img_4.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
							</div>
					</div> -->
					<div class="row" style="padding-bottom: 45px;">
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/Digital_Marketing.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="marketing.html">Marketing</a></h3>

							</div>
						</div>
						<!--<div class="col-md-3 col-sm-6">
							
                              <div class="feature-center">
								<div class="checkimg">
									<img src="photos/ooyala-media-asset-management.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="IP.html">IP & Assest Management</a></h3>
							
							</div>



						</div>-->
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/Consultingtech.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="consulting.html">Consulting</a></h3>
						</div>
						</div>
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/web_designing.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="graphics.html">Graphics & Web Designing</a></h3>
				
							</div>
						</div>
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/Branding.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="branding.html">Branding</a></h3>
			
							</div>
						</div>
						<div class="col-md-4 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/concept_design.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="product.html">Product Design & Modeling</a></h3>
							
							</div>
						</div>
						<div class="col-md-4 col-sm-6">
							
                               <div class="feature-center">
								<div class="checkimg">
									<img src="photos/Targetedleadgeneration.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="targetedleadgeneration.html">Targeted Lead Generation</a></h3>
							
							</div>




						</div>
						<!--<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/fundraising.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="fundraising.html">Fund Raising</a></h3>
						
							</div>
						</div>-->					
					</div>
				</div>
		</div>
			
		<div class="gtco-section" id="gtco-faq" data-section="customers" style="padding-bottom: 0px;">
			<div class="gtco-container">
				<div class="row">
					<div class="col-md-12 gtco-heading" style="margin-left: 34px;">
						<h2 class="gtco-left">Customers</h2>
					</div>
				</div>
				<div class="row logodiv">
					<div class="col-md-3 animate-box" data-animate-effect="bounceInLeft">
						<div class="">
							<img src="images/LichchhwiFoods.jpg" alt="" id="Lich">
						</div>
					</div>
					<div class="col-md-3  animate-box" data-animate-effect="bounceInLeft">
						<div class=""  style="margin-left: -66px;">
							<img src="images/LumbiniElite1.png" alt="" id="LumbiniElite">
						</div>						
					</div>
					<div class="col-md-3  animate-box" data-animate-effect="bounceInLeft">
						<div class="" style=" margin-left: -28px;">
							<img src="images/ElitiaTech1.png" alt="" id="ElitiaTech">
						</div>						
					</div>
					<div class="col-md-3  animate-box" data-animate-effect="bounceInLeft">
						<div class="">
							<img src="images/SkillsBridge1.png" alt="" id="skillsbridge">
						</div>

				</div>
			</div>
		</div>
		<div id="gtco-products" data-section="products">
				<div class="gtco-container">
					<div class="row">
						<div class="col-md-12 gtco-heading" style="margin-left: 34px;">
							<h2 class="gtco-left">Products</h2>
							<p>Our product-driven approach gets straight to the point: making models and ideas tangible and testable very rapidly by putting them in real people’s hands.</p>
						</div>
					</div>
					<!-- 			<div class="row">
							<div class="owl-carousel owl-carousel-carousel">
									<div class="item">
											<img src="images/img_1.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
									<div class="item">
											<img src="images/img_2.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
									<div class="item">
											<img src="images/img_3.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
									<div class="item">
											<img src="images/img_4.jpg" alt="Free HTML5 Bootstrap Template by GetTemplates.co">
									</div>
							</div>
					</div> -->
					<div class="row" style="padding-bottom: 45px;">
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/agrix1.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="images/AgriX.pdf" target="_blank">Agri - X</a></h3>

							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/HR_management.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="images/HR Connect.pdf" target="_blank">HR Connect</a></h3>
							
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/seo-keywords-marketing2.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a href="images/.pdf">Performance Diamond</a></h3>
						</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/project tracker2.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/ProjectTracker.pdf" target="_blank">Project Tracker</a></h3>
				
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/textile.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/lumbini_ERP.pdf" target="_blank">Textile ERP</a></h3>
			
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/lead management.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/.pdf" >Lead Management System</a></h3>
							
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/mARTECH.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/Martech.pdf" target="_blank">Martech</a></h3>
							
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/images.jpg" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/ShipmentTracker.pdf" target="_blank">Shipment Tracker</a></h3>
						
							</div>
						</div>
                            	<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/Solar_X.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/SOLAR-X.pdf" target="_blank">Solar X</a></h3>
			
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/vehicle_tracking.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/vehicle_tracking_solution.pdf" target="_blank">Vehicle Tracking Solution</a></h3>
							
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="feature-center">
								<div class="checkimg">
									<img src="photos/mARTECH.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/Martech.pdf" target="_blank">Supplier Collaboration Tool</a></h3>
							
							</div>
						</div>
                        <div class="col-md-3 col-sm-6">
    						<div class="feature-center">
								<div class="checkimg">
									<img src="photos/mARTECH.png" width="100px" height="100px">
								</div>
								<h3 class="buttondetail"><a class="trans" href="images/Martech.pdf" target="_blank">Dealer and Distributor Management solution</a></h3>
							
							</div>
						</div>
					</div>
				</div>
		</div>
		<div id="gtco-blog" data-section="blogs" class="gtco-blog">
			<p class="blogtext2">Blogs</p>
					<div class="row">
							<div class="owl-carousel owl-carousel-carousel">
									<div class="item" >
								        <div class="card">
								            <h3 class="blogtext">TechnoBizz your Sales Partner for B2B Software, Mobile Apps, Electronics & More</h3>
								                
								            <div class="card-footer">
								                <a  href="blog1.html">Read More....</a>
								            </div>
								        </div>
									</div>
									<!--<div class="item">
								        <div class="card">
                							<h3 class="blogtext">Lean Patent Development Life Cycle (PDLC)</h3>
                					        <div class="card-footer">
                  							<a  href="blog2.html">Read More....</a>
                  						   </div>
							            </div>
									</div>-->
									<!--<div class="item">
								        <div class="card">
               								<h3 class="blogtext">Return on Investment in Patents (ROIP)</h3>
               								<div class="card-footer">
               									<a  href="blog0.html">Read More....</a>
               								</div>
              							</div>
									</div>-->
									<div class="item">								            
              							<div class="card">
                							<h3 class="blogtext">Why Cloud Computing – Strategic Investment Management</h3>

	                  						<div class="card-footer">
							                  <a  href="blog4.html">Read More....</a>
							                </div>
                  						</div>
           							</div>

           							<div class="item">								            
              							<div class="card">
                							<h3 class="blogtext">Introducing TechnoBizz Analytics and Advisory Services LLP</h3>
	                  						<div class="card-footer">
							                  <a  href="blog5.html">Read More....</a>
							                </div>
                  						</div>
           							</div>
									</div>
							</div>
					</div> 		
		</div>
		<div id="gtco-contact" data-section="contact" class="gtco-cover gtco-cover-xs" style="background-image:url(images/contact.jpg);">
				<div class="row">
					<!-- contact -->
					<section class="contact-w3-agileits" id="contact">
						<div class="container">
							<h3 class="text-center animate-box" data-animate-effect="bounceInLeft">Get In Touch</h3>
							<div class="col-lg-4 col-md-4 contact-w3l1 animate-box" data-animate-effect="bounceInLeft">
								<h4>Subscribe to our Newsletter</h4>
								<div class="subscribe">
									<form name="subscribeform" method="post" action="script.php">
										<div class="form-group">
											<input class="form-control" id="email1" name="email1" placeholder="Enter Your Email Address" type="email" required>
										</div>
										<div class="form-group">
											<button class="btn-outline2" type="submit">Subscribe</button>
										</div>
										<div class="clearfix"></div>
									</form>
								</div>	
							</div>
							<div class="col-lg-8 col-md-8 contact-w3l2 animate-box" data-animate-effect="bounceInLeft">
								<form name="contactform" method="post" action="send_form_email.php">
									<div class="form-group col-md-4 col-sm-4">
										<input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required/>
									</div>
									<div class="form-group col-md-4 col-sm-4">
										<input type="email" class="form-control" id="email2" name="email2" placeholder="Your Email" required/>
									</div>
									<div class="form-group col-md-4 col-sm-4">
										<input type="tel" class="form-control" id="phone" name="phone" placeholder="Your Phone" required/>
									</div>
									<div class="clearfix"></div>
									<div class="form-group col-md-12">
										<textarea class="form-control" rows="6" name="message" placeholder="Your Message" required></textarea>
									</div>
									<div class="form-group col-md-12">
										<button type="submit" class="btn-outline2"> Submit</button>
									</div>
									<div class="clearfix"></div>
								</form>	
							</div>
							<div class="clearfix"></div>
						</div>
					</section>
				</div>
				<div class="row">
					<!-- map -->
					<section class="map-w3" data-aos="zoom-in">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.662366598187!2d77.71517121425235!3d12.993433790841529!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1195d0377c13%3A0xc3d9b1fe2dc3cdc2!2sTechnoBizz!5e0!3m2!1sen!2sin!4v1484568768641" width="1920" height="300" frameborder="0" style="border:0" allowfullscreen=""></iframe>
					</section>
					<!-- /map -->
				</div>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo" >
		<div class="gtco-container">

			<div class="row row-pb-md">
			<div class="col-md-6 footerwid">
				<div class="gtco-widget">
					<h3>About Us</h3>
					<p style="text-align: justify;">TechnoBizz is a digital agency made of creative technologists. We create simple and meaningful digital experiences to help them attract and engage their customers. We are at the intersection of creativity, technology and strategy, leveraging our expertise to some of the best brands in the world. Our Digital Marketing services include branding, digital marketing, social media marketing, responsive web designing and application development - We take care of a brand's entire digital presence.</p>
					</div>
				</div>
				<div class="col-md-3">
					<div class="gtco-widget main-nav">
						<h3>Links</h3>
						<ul class="gtco-footer-links">
							<li><a href="http://technobizz.in/" data-nav-section="features">About Us</a></li>
							<li><hr class="hr1wid"></li>
							<li><a href="career.html">Careers</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3">
					<div class="gtco-widget">
						<h3>Contact Us</h3>
						<ul class="gtco-quick-contact">
						<li><a href="#"><i class="fa fa-fax" aria-hidden="true"></i> 080 4203 7777</a></li>
    					<li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i> +91 8105006090</a></li>
						<li><hr class="hr1wid"></li>
						<li><a href="mailto:info@technobizz.in"><i class="fa fa-envelope" aria-hidden="true"></i> info@technobizz.in</a></li>
						<li><hr class="hr1wid"></li>
						
						</ul>
					</div>

					<div id="wk-grid85b" class="uk-grid-width-1-3 uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6 uk-grid-width-xlarge-1-6 uk-grid uk-grid-match uk-grid-small social" data-uk-grid-match="{target:'> div > .uk-panel', row:true}" > 
						<div class="uk-row-first">
							<div class="uk-panel" style="min-height: 33px;">
								<div class="uk-panel-teaser">
									<figure class="uk-overlay uk-overlay-hover "> 
										<img src="photos/f.gif" alt="Facebook" width="50" height="50" style=""> 
										<a class="uk-position-cover" href="https://www.facebook.com/technobizz.india.1" target="_blank"></a> 
									</figure>
								</div>
							</div>
						</div>
						<div>
							<div class="uk-panel" style="min-height: 33px;">
								<div class="uk-panel-teaser">
									<figure class="uk-overlay uk-overlay-hover ">
									 <img src="photos/t.gif" alt="Twitter" width="50" height="50" style=""> 
									 <a class="uk-position-cover" href="https://twitter.com/TechnoBizz_LE" target="_blank"></a> 
									</figure>
								</div>
							</div>
						</div>
						<div>
							<div class="uk-panel" style="min-height: 33px;">
								<div class="uk-panel-teaser">
									<figure class="uk-overlay uk-overlay-hover "> 
										<img src="photos/in.gif" alt="Linkedin" width="50" height="50" style=""> 
										<a class="uk-position-cover" href="https://www.linkedin.com/in/techno-bizz-9b750b157/" target="_blank"></a> 
									</figure>
								</div>
							</div>
						</div>
					</div>					

				</div>
			</div>
			<hr style="border-top: 1px solid #656060;">
 			<div class="row copyright">

			</div>
		</div>
	</footer>

	<!-- go to top -->
<!-- 	<div class="gototop js-top"><a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a></div> -->

	<!-- jQuery -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript" src="dist/jquery.zoomslider.min.js"></script>

	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

</body>
</html>